pub mod core;
pub mod infrastructure;
pub mod interface_adapters;
pub mod use_cases;

#[cfg(test)]
mod tests;
